package chronosPack;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import fairyChessPack1.Epifyte;
import fairyChessPack1.EpifyteArm;
import fairyChessPack1.EpifyteModifier;
import main.DataSet;
import main.MethodPiece;
import main.Piece;
import main.PieceTreeCompiler;
import main.SlotPath;

public class InitializerDefault extends MethodPiece{
	
	public static ArrayList<SlotPath> getPossibleFits(){
		ArrayList<String> hostPath = new ArrayList<String>(Arrays.asList("Chronos"));
		String slotName = "INITIALIZERSLOT";
		ArrayList<SlotPath> possibleFits = new ArrayList<SlotPath>(
				Arrays.asList(new SlotPath(hostPath, slotName)));
		return possibleFits;
	}
	
	public static Map<String, Integer> getMethodPieceSlots(){
		return Piece.makeSimpleSlotList();//TODO
	}
	public static Map<String, Integer> getObjectPieceSlots(){
		return Piece.makeSimpleSlotList();//TODO
	}
	public static ArrayList<String> getDependentPieceNames(){
		return new ArrayList<String>();
	}
	public static void initialize(){
		//TODO
		PieceTreeCompiler.getPieceClassToStaticNamedDataSupersetMap()
		.put(PieceTreeCompiler.getPieceClassToProjectionMap().get(InitializerDefault.class)
				.getHostPiece().getOrigin(), new HashMap<String, DataSet>());
		PieceTreeCompiler.getPieceClassToStaticDataSupersetMap()
		.put(PieceTreeCompiler.getPieceClassToProjectionMap().get(InitializerDefault.class)
				.getHostPiece().getOrigin(), new HashMap<Class<Piece>, DataSet>());
		PieceTreeCompiler.getPieceClassToStaticNamedDataSupersetMap()
		.get(PieceTreeCompiler.getPieceClassToProjectionMap().get(InitializerDefault.class)
				.getHostPiece().getOrigin()).put("roundControllers", 
						new DataSet(ArrayList.class, new ArrayList<Agent>()));
		//Roughly speaking, the above lines serve to prevent NullPointerException
	}
	private static Epifyte createCartesianSquareBoardOfDimensions(Integer width, Integer height){
		Epifyte squareBoard = new Epifyte();
		squareBoard.setTags("BOARD", "CARTESIAN", "SQUARE");
		Map<ArrayList<Integer>, Epifyte> coordinatesToCellMapRaw = new HashMap<ArrayList<Integer>, Epifyte>();
		
		for(int i = 1; i < width; i++){
			for(int j = 1; j < height; j++){
				Epifyte cell = new Epifyte();
				cell.setTags("BOARD_CELL");
				cell.setDataSet("coordinates", new DataSet(ArrayList.class, 
						new ArrayList<Integer>(Arrays.asList(i, j))));
				Epifyte.forceBind(cell, squareBoard);
				coordinatesToCellMapRaw.put(new ArrayList<Integer>(Arrays.asList(i, j)), cell);
			}
		}
		DataSet coordinatesToCellMap = new DataSet(Map.class, coordinatesToCellMapRaw);
		squareBoard.setDataSet("coordinatesToCellMap", coordinatesToCellMap);
		squareBoard.setDataSet("width", new DataSet(Integer.class, width));
		squareBoard.setDataSet("height", new DataSet(Integer.class, height));
			PieceTreeCompiler.getPieceClassToStaticNamedDataSupersetMap()
			.putIfAbsent(InitializerDefault.class, new HashMap<String, DataSet>());
		PieceTreeCompiler.getPieceClassToStaticNamedDataSupersetMap().
			get(InitializerDefault.class).put("squareBoardReference", 
							new DataSet(Epifyte.class, squareBoard));
		return squareBoard;
	}
	private static void putGamePieceOnSquareBoard(Epifyte gamePiece, Epifyte squareBoard, 
			ArrayList<Integer> coordinates){
		Map<ArrayList<Integer>, Epifyte> coordinatesToCellMapRaw = 
				(Map<ArrayList<Integer>, Epifyte>) squareBoard.getDataSet("coordinatesToCellMap").getEntry();
		Epifyte targetCell = coordinatesToCellMapRaw.get(coordinates);
		Epifyte.forceBind(gamePiece, targetCell);
		//Consider if attemptBind is better
	}
	private static EpifyteModifier makeIdentityBundle(String pieceType){
		
	}
	private static EpifyteArm makeChessMoveArm(String pieceType){
		EpifyteArm chessMoveArm = new EpifyteArm();
		chessMoveArm.setEpifyteCommandHandler((command, commandRoute, supportDataSet)
				-> {
					if(command == "move"){
						if(supportDataSet.getEntryType() == Epifyte.class){
							Epifyte cellPresumed = (Epifyte) supportDataSet.getEntry();
							if(cellPresumed.getTags().contains("BOARD_CELL")){
								boolean flag = false;
								Epifyte currentCell = null;
								if(commandRoute.get(0).getSingleLowerOfTag("BOARD_CELL") != null){
									currentCell = commandRoute.get(0).getSingleLowerOfTag("BOARD_CELL");
									flag = true;
								}
								if(flag == true){
								Epifyte.forceMove(commandRoute.get(0), currentCell, cellPresumed);
								}
							}
						}
					}
					
				});
		if(pieceType == "Rook"){
			EpifyteModifier basicMovementRange = new EpifyteModifier();
			basicMovementRange.setEpifyteInformationFinder((informationName, propagatedDataSet
					, informationRoute, supportDataSet) -> {
						if(informationName == "movementRange"){
							//This should return a dataset containing an arraylist of cells
						DataSet dataSet = propagatedDataSet;
						if(propagatedDataSet == null){
							dataSet = new DataSet(ArrayList.class, new ArrayList<Epifyte>());
						}
						ArrayList<Epifyte> validCellList = (ArrayList<Epifyte>) dataSet.presentAsArrayList();
						Epifyte hostBoard = informationRoute.get(0).getSingleLowerOfTag("BOARD");
						if(hostBoard == null){
							return propagatedDataSet;
						}
						ArrayList<Integer> coordinates = (ArrayList<Integer>) 
								informationRoute.get(0).getDataSet("coordinates").presentAsArrayList();
						int currentX = coordinates.get(0);
						int currentY = coordinates.get(1);
						DataSet coordinatesToCellMap = hostBoard.getDataSet("coordinatesToCellMap");
						Map<ArrayList<Integer>, Epifyte> coordinatesToCellMapRaw
						= (Map<ArrayList<Integer>, Epifyte>) coordinatesToCellMap;
						ArrayList<Epifyte> dataSetArrayList = 
								(ArrayList<Epifyte>) dataSet.presentAsArrayList();
						//Horizontal movement
						for(int i = 1; true; i++){
							if(coordinatesToCellMapRaw.get(
									new ArrayList<Integer>(Arrays.asList(i, currentY))) == null){
								break;
							}
							else if(i != currentX){
								dataSetArrayList.add(coordinatesToCellMapRaw
										.get(new ArrayList<Integer>(Arrays.asList(i, currentY))));
							}
						}
						}
						return propagatedDataSet;
					});
		}
	}
	private static EpifyteArm makeChessAttackArm(String pieceType){
		
	}
	public static void executeProcess(String processName){
		//To be rewritten
	}
	public static void executeProcessWithDataSet(String processName, DataSet dataSet){
		//To be rewritten
	}
}
