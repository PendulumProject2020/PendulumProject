package fairyChessPack1;

import main.DataSet;

@FunctionalInterface
public interface EpifytePrototype {
	public Epifyte make(DataSet dataSet);
}
