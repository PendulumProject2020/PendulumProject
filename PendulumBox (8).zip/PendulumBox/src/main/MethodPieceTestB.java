package main;

public class MethodPieceTestB extends MethodPiece{

}
