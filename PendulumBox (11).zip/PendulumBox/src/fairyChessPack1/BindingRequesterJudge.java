package fairyChessPack1;

import main.Trilean;

@FunctionalInterface
public interface BindingRequesterJudge {
	public Trilean canBindTo(Epifyte epifyte);
}
