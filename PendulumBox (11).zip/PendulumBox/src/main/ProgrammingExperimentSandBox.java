package main;

import java.io.Serializable;

public class ProgrammingExperimentSandBox {
	Class<Serializable> x;
}
