package main;

public enum Trilean {
	TRUE, FALSE, UNDECIDED;
}
