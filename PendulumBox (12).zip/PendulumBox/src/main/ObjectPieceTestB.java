package main;

public class ObjectPieceTestB extends ObjectPiece{

}
