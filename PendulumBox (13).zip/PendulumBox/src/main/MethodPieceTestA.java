package main;

public class MethodPieceTestA extends MethodPiece{

}
