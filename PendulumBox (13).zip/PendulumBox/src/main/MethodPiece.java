package main;

public class MethodPiece extends Piece{
	
	public static void executeProcess(String processName){
		//To be rewritten
	}
	public static void executeProcessWithDataSet(String processName, DataSet dataSet){
		//To be rewritten
	}
	public static DataSet evaluateStaticInformation(String informationName){
		return null;
		//To be rewritten
	}
	public static DataSet evaluateStaticInformationWithDataSet(String informationName, DataSet dataSet){
		return null;
		//To be rewritten
	}
}
