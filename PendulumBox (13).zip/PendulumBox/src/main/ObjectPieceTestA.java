package main;

public class ObjectPieceTestA extends ObjectPiece{

}
