package pieceTreeDisplayPack;

public enum SlotType {
	EMPTY_SQUARE, FILLED_SQUARE, EMPTY_CIRCLE, FILLED_CIRCLE, GREEN_SQUARE, GREEN_CIRCLE;
	//"Green" means it is in a megaslot
}
