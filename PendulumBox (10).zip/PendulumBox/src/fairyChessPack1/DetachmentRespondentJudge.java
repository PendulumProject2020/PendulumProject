package fairyChessPack1;

import main.Trilean;

@FunctionalInterface
public interface DetachmentRespondentJudge {
	public Trilean canBeDetachedBy(Epifyte epifyte);
}
