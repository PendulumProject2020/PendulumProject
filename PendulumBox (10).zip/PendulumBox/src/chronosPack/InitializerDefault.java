package chronosPack;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import fairyChessPack1.ControllerProxyFactory;
import fairyChessPack1.Epifyte;
import fairyChessPack1.EpifyteArm;
import fairyChessPack1.EpifyteDisplayEventInterpreter;
import fairyChessPack1.EpifyteModifier;
import fairyChessPack1.InputCommandConverter;
import javafx.event.EventHandler;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import main.DataSet;
import main.MethodPiece;
import main.Pair;
import main.Piece;
import main.PieceTreeCompiler;
import main.Quintuple;
import main.SlotPath;
import main.World;

public class InitializerDefault extends MethodPiece{
	
	private static EpifyteModifier whiteControllerProxy;
	private static EpifyteModifier blackControllerProxy;
	private static RoundController autoExecutionController = new RoundController();
	public static ArrayList<SlotPath> getPossibleFits(){
		ArrayList<String> hostPath = new ArrayList<String>(Arrays.asList("Chronos"));
		String slotName = "INITIALIZERSLOT";
		ArrayList<SlotPath> possibleFits = new ArrayList<SlotPath>(
				Arrays.asList(new SlotPath(hostPath, slotName)));
		return possibleFits;
	}
	
	public static Map<String, Integer> getMethodPieceSlots(){
		return Piece.makeSimpleSlotList();//TODO
	}
	public static Map<String, Integer> getObjectPieceSlots(){
		return Piece.makeSimpleSlotList();//TODO
	}
	public static ArrayList<String> getDependentPieceNames(){
		return new ArrayList<String>();
	}
	public static void initialize(){
		//TODO
		PieceTreeCompiler.getPieceClassToStaticNamedDataSupersetMap()
		.put(PieceTreeCompiler.getPieceClassToProjectionMap().get(InitializerDefault.class)
				.getHostPiece().getOrigin(), new HashMap<String, DataSet>());
		PieceTreeCompiler.getPieceClassToStaticDataSupersetMap()
		.put(PieceTreeCompiler.getPieceClassToProjectionMap().get(InitializerDefault.class)
				.getHostPiece().getOrigin(), new HashMap<Class<Piece>, DataSet>());
		/*PieceTreeCompiler.getPieceClassToStaticNamedDataSupersetMap()
		.get(PieceTreeCompiler.getPieceClassToProjectionMap().get(InitializerDefault.class)
				.getHostPiece().getOrigin()).put("roundControllers", 
						new DataSet(ArrayList.class, new ArrayList<Agent>()));*/
		//Roughly speaking, the above lines serve to prevent NullPointerException
		setWhiteControllerProxy(ControllerProxyFactory.makeControllerProxy("White"));
		setBlackControllerProxy(ControllerProxyFactory.makeControllerProxy("Black"));
	}
	private static Epifyte createCartesianSquareBoardOfDimensions(Integer width, Integer height,
			Double displayWidth, Double displayHeight){
		Epifyte squareBoard = new Epifyte();
		squareBoard.setTags("BOARD", "CARTESIAN", "SQUARE");
		Map<Pair<Integer, Integer>, Epifyte> coordinatesToCellMapRaw 
		= new HashMap<Pair<Integer, Integer>, Epifyte>();
		
		for(int i = 1; i < width; i++){
			for(int j = 1; j < height; j++){
				Integer iConstant = i;
				Integer jConstant = j;
				Epifyte cell = new Epifyte();
				cell.setTags("BOARD_CELL");
				cell.setDataSet("coordinates", new DataSet(Pair.class, new Pair<Integer, Integer>(i, j)));
				Epifyte.forceBind(cell, squareBoard);
				coordinatesToCellMapRaw.put(new Pair<Integer, Integer>(i, j), cell);
				EpifyteModifier texture = new EpifyteModifier();
				Double boardWidth = new Double((Integer) texture.getSingleLowerOfTag("BOARD_CELL")
						.getSingleLowerOfTag("BOARD").getDataSet("width").getEntry());
				Double boardHeight = new Double((Integer) texture.getSingleLowerOfTag("BOARD_CELL")
						.getSingleLowerOfTag("BOARD").getDataSet("height").getEntry());
				Double boardDisplayWidth = (Double) texture.getSingleLowerOfTag("BOARD_CELL")
						.getSingleLowerOfTag("BOARD").getDataSet("displayWidth").getEntry();
				Double boardDisplayHeight = (Double) texture.getSingleLowerOfTag("BOARD_CELL")
						.getSingleLowerOfTag("BOARD").getDataSet("displayHeight").getEntry();
				Double cellWidth = boardDisplayWidth / boardWidth;
				Double cellHeight = boardDisplayHeight / boardHeight;
				Rectangle square = new Rectangle();
				square.setWidth(cellWidth);
				square.setHeight(cellHeight);
				if((iConstant + jConstant) % 2 == 0){
					square.setFill(Color.BLACK);
				}
				else{
					square.setFill(Color.WHITE);
				}
				texture.setTags("TEXTURE");
				texture.setDataSet("texture", new DataSet(Rectangle.class, square));
				texture.setDataSet("visibility", new DataSet(Boolean.class, true));
				texture.setEpifyteInformationFinder((informationName, propagatedDataSet, 
						informationRoute, SupportDataSet) -> {
							Double boardWidth1 = new Double((Integer) texture.getSingleLowerOfTag("BOARD_CELL")
									.getSingleLowerOfTag("BOARD").getDataSet("width").getEntry());
							Double boardHeight1 = new Double((Integer) texture.getSingleLowerOfTag("BOARD_CELL")
									.getSingleLowerOfTag("BOARD").getDataSet("height").getEntry());
							Double boardDisplayWidth1 = (Double) texture.getSingleLowerOfTag("BOARD_CELL")
									.getSingleLowerOfTag("BOARD").getDataSet("displayWidth").getEntry();
							Double boardDisplayHeight1 = (Double) texture.getSingleLowerOfTag("BOARD_CELL")
									.getSingleLowerOfTag("BOARD").getDataSet("displayHeight").getEntry();
							Double cellWidth1 = boardDisplayWidth1 / boardWidth1;
							Double cellHeight1 = boardDisplayHeight1 / boardHeight1;
						if(informationName == "texture"){
							return new DataSet(Rectangle.class, texture.getDataSet("texture").getEntry());
						}
						if(informationName == "relativeDisplayCoordinates"){
							Pair<Integer, Integer> coordinates = 
									(Pair<Integer, Integer>) texture.getSingleLowerOfTag("BOARD_CELL")
									.getDataSet("coordinates").getEntry();
							Integer x = coordinates.getFirst();
							Integer y = coordinates.getSecond();
							//Display coordinates relative to the lower texture
							return new DataSet(Pair.class, new Pair<Double, Double>(
									cellWidth1*(((Double) (boardWidth1 + 1))/2.0 - 
											new Double(x))
									, -cellHeight1*(((Double) (boardHeight1 + 1))/2.0 - new Double(y))));
						}
						if(informationName == "visibility"){
							return new DataSet(Boolean.class, texture.getDataSet("visibility").getEntry());
						}
						return propagatedDataSet;
					});
				texture.setRoundExecutor(() -> {
					//TODO
				});
			}
		}
		DataSet coordinatesToCellMap = new DataSet(Map.class, coordinatesToCellMapRaw);
		squareBoard.setDataSet("coordinatesToCellMap", coordinatesToCellMap);
		squareBoard.setDataSet("width", new DataSet(Integer.class, width));
		squareBoard.setDataSet("height", new DataSet(Integer.class, height));
		squareBoard.setDataSet("displayWidth", new DataSet(Double.class, displayWidth));
		squareBoard.setDataSet("displayHeight", new DataSet(Double.class, displayHeight));
			PieceTreeCompiler.getPieceClassToStaticNamedDataSupersetMap()
			.putIfAbsent(InitializerDefault.class, new HashMap<String, DataSet>());
		PieceTreeCompiler.getPieceClassToStaticNamedDataSupersetMap().
			get(InitializerDefault.class).put("squareBoardReference", 
							new DataSet(Epifyte.class, squareBoard));
		return squareBoard;
	}
	private static void putGamePieceOnSquareBoard(Epifyte gamePiece, Epifyte squareBoard, 
			Pair<Integer, Integer> coordinates){
		Map<Pair<Integer, Integer>, Epifyte> coordinatesToCellMapRaw = 
				(Map<Pair<Integer, Integer>, Epifyte>) 
				squareBoard.getDataSet("coordinatesToCellMap").getEntry();
		Epifyte targetCell = coordinatesToCellMapRaw.get(coordinates);
		Epifyte.forceBind(gamePiece, targetCell);
		//Consider if attemptBind is better
	}
	private static Epifyte makeChessPiece(EpifyteModifier identityBundle){
		Epifyte chessPiece = new Epifyte();
		chessPiece.setTags("CHESS_PIECE");
		Epifyte.forceBind(identityBundle, chessPiece);
		EpifyteDisplayEventInterpreter.addConverter(chessPiece, makeInputCommandConverter(chessPiece));
		return chessPiece;
	}
	private static InputCommandConverter makeInputCommandConverter(Epifyte chessPiece){
		//TODO
		InputCommandConverter inputCommandConverter = (event, supportDataSet) -> {
			if(event.getClass().isAssignableFrom(MouseEvent.class)){
				if(World.isUserInteraction() == true){
					//TODO
				}
			}
		};
	}
	private static void gamePieceSetControllerProxy(Epifyte gamePiece, EpifyteModifier controllerProxy){
		Epifyte.forceBind(controllerProxy, gamePiece);
	}
	private static EpifyteModifier makeIdentityBundle(String pieceType, String colorName){
		EpifyteModifier identityBundle = new EpifyteModifier();
		identityBundle.setTags("IDENTITY_BUNDLE");
		EpifyteModifier type = makeType(pieceType);
		Epifyte.forceBind(type, identityBundle);
		EpifyteModifier texture = makeTexture(pieceType, colorName);
		Epifyte.forceBind(texture, identityBundle);
		EpifyteArm moveArm = makeChessMoveArm(pieceType);
		Epifyte.forceBind(moveArm, identityBundle);
		EpifyteArm attackArm = makeChessAttackArm(pieceType);
		Epifyte.forceBind(attackArm, identityBundle);
		return identityBundle;
	}
	private static EpifyteModifier makeType(String pieceType){
		EpifyteModifier type = new EpifyteModifier();
		type.setTags("TYPE");
		type.setEpifyteInformationFinder((informationName, propagatedDataSet, 
				informationRoute, SupportDataSet) -> {
				if(informationName == "type"){
					return new DataSet(EpifyteModifier.class, pieceType);
				}
				return propagatedDataSet;
			}
		);
		return type;
	}
	private static EpifyteModifier makeTexture(String pieceType, String colorName){
		Image chessPieceImage = new Image("fairyChessPack1/imageFolder1/Chess_xxx60.png", 60, 60, false, false);
		if(pieceType == "Rook" && colorName == "White"){
			chessPieceImage = new Image("fairyChessPack1/imageFolder1/Chess_rlt60.png", 60, 60, false, false);
		}
		else if(pieceType == "Rook" && colorName == "Black"){
			chessPieceImage = new Image("fairyChessPack1/imageFolder1/Chess_rdt60.png", 60, 60, false, false);
		}
		ImageView chessPieceImageView = new ImageView(chessPieceImage);
		EpifyteModifier texture = new EpifyteModifier();
		texture.setTags("TEXTURE");
		chessPieceImageView.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>()
				{
					@Override
					public void handle(MouseEvent arg0) {
						// TODO Auto-generated method stub
						EpifyteDisplayEventInterpreter.executeConverter(texture
								.getSingleLowerOfTag("IDENTITY_BUNDLE").getSingleLowerOfTag("CHESS_PIECE")
								, arg0, null);
					}
				});
		
		texture.setEpifyteInformationFinder((informationName, propagatedDataSet, 
				informationRoute, SupportDataSet) -> {
				if(informationName == "texture"){
					return new DataSet(ImageView.class, chessPieceImageView);
				}
				if(informationName == "relativeDisplayCoordinates"){
					//Display coordinates relative to the lower texture
					return new DataSet(Pair.class, new Pair<Double, Double>(0.0, 0.0));
				}
				return propagatedDataSet;
			}
		);
		return texture;
	}
	private static EpifyteArm makeChessMoveArm(String pieceType){
		EpifyteArm chessMoveArm = new EpifyteArm();
		chessMoveArm.setTags("MOVE_ARM");
		chessMoveArm.setEpifyteCommandHandler((command, commandRoute, supportDataSet)
				-> {
					if(command == "move"){
						if(supportDataSet.getEntryType() == Epifyte.class){
							Epifyte cellPresumed = (Epifyte) supportDataSet.getEntry();
							if(cellPresumed.getTags().contains("BOARD_CELL")){
								boolean flag = false;
								Epifyte currentCell = null;
								if(commandRoute.get(0).getSingleLowerOfTag("BOARD_CELL") != null){
									currentCell = commandRoute.get(0).getSingleLowerOfTag("BOARD_CELL");
									flag = true;
								}
								if(flag == true){
								Epifyte.forceMove(commandRoute.get(0), currentCell, cellPresumed);
								}
							}
						}
					}
					
				});
		if(pieceType == "Rook"){
			EpifyteModifier basicMovementRange = new EpifyteModifier();
			basicMovementRange.setEpifyteInformationFinder((informationName, propagatedDataSet
					, informationRoute, supportDataSet) -> {
						if(informationName == "movementRange"){
							//This should return a dataset containing an arraylist of cells
							//The propagated dataset should also be an arraylist of cells
						Quintuple<Map<Pair<Integer, Integer>, Epifyte>, Integer, Integer, ArrayList<Epifyte>, DataSet>
						informationQuintuple = helper1(informationName, propagatedDataSet
								, informationRoute, supportDataSet);
						if(informationQuintuple == null){
							return propagatedDataSet;
						}
						Map<Pair<Integer, Integer>, Epifyte> coordinatesToCellMapRaw
						= informationQuintuple.getFirst();
						int currentX = informationQuintuple.getSecond();
						int currentY = informationQuintuple.getThird();
						ArrayList<Epifyte> dataSetArrayList = informationQuintuple.getFourth();
						DataSet dataSet = informationQuintuple.getFifth();
						//Horizontal movement
						for(int i = 1; true; i++){
							if(coordinatesToCellMapRaw.get(
									new ArrayList<Integer>(Arrays.asList(i, currentY))) == null){
								break;
							}
							else if(i != currentX){
								dataSetArrayList.add(coordinatesToCellMapRaw
										.get(new ArrayList<Integer>(Arrays.asList(i, currentY))));
							}
						}
						//Vertical movement
						for(int j = 1; true; j++){
							if(coordinatesToCellMapRaw.get(
									new ArrayList<Integer>(Arrays.asList(currentX, j))) == null){
								break;
							}
							else if(j != currentX){
								dataSetArrayList.add(coordinatesToCellMapRaw
										.get(new ArrayList<Integer>(Arrays.asList(currentX, j))));
							}
						}
						dataSet.setEntry(dataSetArrayList);//Not sure if this line is necessary
						return dataSet;
						}
						return propagatedDataSet;
					});
			EpifyteModifier obstructionDetector = new EpifyteModifier();
			obstructionDetector.setEpifyteInformationFinder((informationName, propagatedDataSet
					, informationRoute, supportDataSet) -> {
						if(informationName == "movementRange"){
							//This should return a dataset containing an arraylist of cells
							//The propagated dataset should also be an arraylist of cells
							Quintuple<Map<Pair<Integer, Integer>, Epifyte>, Integer, Integer, ArrayList<Epifyte>, DataSet>
							informationQuintuple = helper1(informationName, propagatedDataSet
									, informationRoute, supportDataSet);
							if(informationQuintuple == null){
								return propagatedDataSet;
							}
							Map<Pair<Integer, Integer>, Epifyte> coordinatesToCellMapRaw
							= informationQuintuple.getFirst();
							int currentX = informationQuintuple.getSecond();
							int currentY = informationQuintuple.getThird();
							ArrayList<Epifyte> dataSetArrayList = informationQuintuple.getFourth();
							DataSet dataSet = informationQuintuple.getFifth();
						//Left obstruction
						for(int i = currentX - 1; i >= 1; i--){//Check if this line is correct
							if(coordinatesToCellMapRaw.get(
									new ArrayList<Integer>(Arrays.asList(i, currentY))) == null){
								break;
							}
							if(coordinatesToCellMapRaw
									.get(new ArrayList<Integer>(Arrays.asList(i, currentY)))
									.getSingleUpperOfTag("CHESS_PIECE") != null
									){
								for(int i2 = i; i2 >= 1; i2--){
									if(coordinatesToCellMapRaw.get(
											new ArrayList<Integer>(Arrays.asList(i2, currentY))) == null){
											break;
										}
								dataSetArrayList.remove(coordinatesToCellMapRaw
										.get(new ArrayList<Integer>(Arrays.asList(i2, currentY))));
								}
							}
						}
						//Right obstruction
						for(int i = currentX + 1; true; i++){//Check if this line is correct
							if(coordinatesToCellMapRaw.get(
									new ArrayList<Integer>(Arrays.asList(i, currentY))) == null){
								break;
							}
							if(coordinatesToCellMapRaw
									.get(new ArrayList<Integer>(Arrays.asList(i, currentY)))
									.getSingleUpperOfTag("CHESS_PIECE") != null
									){
								for(int i2 = i; true; i2++){
								if(coordinatesToCellMapRaw.get(
									new ArrayList<Integer>(Arrays.asList(i2, currentY))) == null){
									break;
								}
								dataSetArrayList.remove(coordinatesToCellMapRaw
									.get(new ArrayList<Integer>(Arrays.asList(i2, currentY))));
								}
							}
						}
						//Down obstruction
						for(int j = currentY - 1; j >= 1; j--){//Check if this line is correct
							if(coordinatesToCellMapRaw.get(
									new ArrayList<Integer>(Arrays.asList(currentX, j))) == null){
								break;
							}
							if(coordinatesToCellMapRaw
									.get(new ArrayList<Integer>(Arrays.asList(currentX, j)))
									.getSingleUpperOfTag("CHESS_PIECE") != null
									){
								for(int j2 = j; j2 >= 1; j2--){
								if(coordinatesToCellMapRaw.get(
										new ArrayList<Integer>(Arrays.asList(currentX, j2))) == null){
										break;
									}
								dataSetArrayList.remove(coordinatesToCellMapRaw
										.get(new ArrayList<Integer>(Arrays.asList(currentX, j2))));
								}
							}
						}
						//Up obstruction
						for(int j = currentX + 1; true; j++){//Check if this line is correct
							if(coordinatesToCellMapRaw.get(
									new ArrayList<Integer>(Arrays.asList(currentX, j))) == null){
								break;
							}
							if(coordinatesToCellMapRaw
									.get(new ArrayList<Integer>(Arrays.asList(currentX, j)))
									.getSingleUpperOfTag("CHESS_PIECE") != null
									){
								for(int j2 = j; true; j2++){
								if(coordinatesToCellMapRaw.get(
									new ArrayList<Integer>(Arrays.asList(currentX, j2))) == null){
									break;
								}
								dataSetArrayList.remove(coordinatesToCellMapRaw
									.get(new ArrayList<Integer>(Arrays.asList(currentX, j2))));
								}
							}
						}
						dataSet.setEntry(dataSetArrayList);//Not sure if this line is necessary
						return dataSet;
						}
						return propagatedDataSet;
					});
			Epifyte.forceBind(obstructionDetector, basicMovementRange);
			Epifyte.forceBind(basicMovementRange, chessMoveArm);
		}
		//TODO
		return chessMoveArm;
	}
	
	private static Quintuple<Map<Pair<Integer, Integer>, Epifyte>, Integer, Integer, ArrayList<Epifyte>, DataSet> 
	//coordinatesToCellMapRaw, currentX, currentY, dataSetArrayList, dataSet
	helper1(String informationName, DataSet propagatedDataSet
			, ArrayList<Epifyte> informationRoute, DataSet supportDataSet){
		DataSet dataSet = propagatedDataSet;
		if(propagatedDataSet == null){
			dataSet = new DataSet(ArrayList.class, new ArrayList<Epifyte>());
		}
		ArrayList<Epifyte> validCellList = (ArrayList<Epifyte>) dataSet.presentAsArrayList();
		Epifyte hostBoard = informationRoute.get(0).getSingleLowerOfTag("BOARD");
		if(hostBoard == null){
			return null;
		}
		Pair<Integer, Integer> coordinates = (Pair<Integer, Integer>) 
				informationRoute.get(0).getDataSet("coordinates").getEntry();
		int currentX = coordinates.getFirst();
		int currentY = coordinates.getSecond();
		DataSet coordinatesToCellMap = hostBoard.getDataSet("coordinatesToCellMap");
		Map<Pair<Integer, Integer>, Epifyte> coordinatesToCellMapRaw
		= (Map<Pair<Integer, Integer>, Epifyte>) coordinatesToCellMap;
		ArrayList<Epifyte> dataSetArrayList = 
				(ArrayList<Epifyte>) dataSet.presentAsArrayList();
		return new Quintuple<Map<Pair<Integer, Integer>, Epifyte>, Integer, Integer, ArrayList<Epifyte>, 
				DataSet>(coordinatesToCellMapRaw, currentX, currentY, dataSetArrayList, dataSet);
	}
	
	private static EpifyteArm makeChessAttackArm(String pieceType){
		EpifyteArm chessAttackArm = new EpifyteArm();
		chessAttackArm.setTags("ATTACK_ARM");
		chessAttackArm.setEpifyteCommandHandler((command, commandRoute, supportDataSet)
				-> {
					if(command == "attack"){
						if(supportDataSet.getEntryType() == Epifyte.class){
							Epifyte cellPresumed = (Epifyte) supportDataSet.getEntry();
							if(cellPresumed.getTags().contains("BOARD_CELL")){
								boolean flag = false;
								Epifyte currentCell = null;
								if(commandRoute.get(0).getSingleLowerOfTag("BOARD_CELL") != null){
									currentCell = commandRoute.get(0).getSingleLowerOfTag("BOARD_CELL");
									flag = true;
								}
								if(flag == true){
								Epifyte.forceMove(commandRoute.get(0), currentCell, cellPresumed);
								Epifyte.forceDetach(
										cellPresumed.getSingleUpperOfTag("CHESS_PIECE"), cellPresumed);
								}
							}
						}
					}
					
				});
		if(pieceType == "Rook"){
			EpifyteModifier pieceDetector = new EpifyteModifier();
			//Modification to obstructionDetector
			pieceDetector.setEpifyteInformationFinder((informationName, propagatedDataSet
					, informationRoute, supportDataSet) -> {
						if(informationName == "attackRange"){
							//This should return a dataset containing an arraylist of cells
							//The propagated dataset should also be an arraylist of cells
							Quintuple<Map<Pair<Integer, Integer>, Epifyte>, Integer, Integer, ArrayList<Epifyte>, DataSet>
							informationQuintuple = helper1(informationName, propagatedDataSet
									, informationRoute, supportDataSet);
							if(informationQuintuple == null){
								return propagatedDataSet;
							}
							Map<Pair<Integer, Integer>, Epifyte> coordinatesToCellMapRaw
							= informationQuintuple.getFirst();
							int currentX = informationQuintuple.getSecond();
							int currentY = informationQuintuple.getThird();
							ArrayList<Epifyte> dataSetArrayList = informationQuintuple.getFourth();
							DataSet dataSet = informationQuintuple.getFifth();
							ArrayList<Epifyte> newDataSetArrayList
							= new ArrayList<Epifyte>();
						//Left piece detection
						for(int i = currentX - 1; i >= 1; i--){//Check if this line is correct
							if(coordinatesToCellMapRaw.get(
									new ArrayList<Integer>(Arrays.asList(i, currentY))) == null){
								break;
							}
							if(coordinatesToCellMapRaw
									.get(new ArrayList<Integer>(Arrays.asList(i, currentY)))
									.getSingleUpperOfTag("CHESS_PIECE") != null){
								newDataSetArrayList.add(coordinatesToCellMapRaw
										.get(new ArrayList<Integer>(Arrays.asList(i, currentY))));
							}
						}
						//Right piece detection
						for(int i = currentX + 1; true; i++){//Check if this line is correct
							if(coordinatesToCellMapRaw.get(
									new ArrayList<Integer>(Arrays.asList(i, currentY))) == null){
								break;
							}
							if(coordinatesToCellMapRaw
									.get(new ArrayList<Integer>(Arrays.asList(i, currentY)))
									.getSingleUpperOfTag("CHESS_PIECE") != null
									){
								newDataSetArrayList.add(coordinatesToCellMapRaw
									.get(new ArrayList<Integer>(Arrays.asList(i, currentY))));
							}
						}
						//Down piece detection
						for(int j = currentY - 1; j >= 1; j--){//Check if this line is correct
							if(coordinatesToCellMapRaw.get(
									new ArrayList<Integer>(Arrays.asList(currentX, j))) == null){
								break;
							}
							if(coordinatesToCellMapRaw
									.get(new ArrayList<Integer>(Arrays.asList(currentX, j)))
									.getSingleUpperOfTag("CHESS_PIECE") != null
									){
								newDataSetArrayList.add(coordinatesToCellMapRaw
										.get(new ArrayList<Integer>(Arrays.asList(currentX, j))));
							}
						}
						//Up piece detection
						for(int j = currentX + 1; true; j++){//Check if this line is correct
							if(coordinatesToCellMapRaw.get(
									new ArrayList<Integer>(Arrays.asList(currentX, j))) == null){
								break;
							}
							if(coordinatesToCellMapRaw
									.get(new ArrayList<Integer>(Arrays.asList(currentX, j)))
									.getSingleUpperOfTag("CHESS_PIECE") != null
									){
								dataSetArrayList.add(coordinatesToCellMapRaw
									.get(new ArrayList<Integer>(Arrays.asList(currentX, j))));
							}
						}
						dataSet.setEntry(newDataSetArrayList);
						return dataSet;
						}
						return propagatedDataSet;
					});
			//TODO
		}
	}
	public static void executeProcess(String processName){
		//To be rewritten
	}
	public static void executeProcessWithDataSet(String processName, DataSet dataSet){
		//To be rewritten
	}

	public static EpifyteModifier getWhiteControllerProxy() {
		return whiteControllerProxy;
	}

	public static void setWhiteControllerProxy(EpifyteModifier whiteControllerProxy) {
		InitializerDefault.whiteControllerProxy = whiteControllerProxy;
	}

	public static EpifyteModifier getBlackControllerProxy() {
		return blackControllerProxy;
	}

	public static void setBlackControllerProxy(EpifyteModifier blackControllerProxy) {
		InitializerDefault.blackControllerProxy = blackControllerProxy;
	}

	public static RoundController getAutoExecutionController() {
		return autoExecutionController;
	}

	public static void setAutoExecutionController(RoundController autoExecutionController) {
		InitializerDefault.autoExecutionController = autoExecutionController;
	}
}
