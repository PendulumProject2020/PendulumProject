package chronosPack;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

import main.ObjectPiece;
import main.PieceTreeCompiler;

public class RoundController extends Agent{
	private ArrayList<Agent> roundControlTargets = new ArrayList<Agent>();
	private Queue<Agent> targetQueue = new LinkedList<Agent>();
	private boolean turnOngoing = false;
	public RoundController(){
		this.setActualClass(RoundController.class);
		this.setDefaultCommandExecuter();
		this.setDefaultInstanceInformationEvaluator();
		this.setDefaultRoundExecutor();
	}
	@Override
	public void setDefaultCommandExecuter(){
		//To be overridden
		this.setCommandExecutor((target, command, dataSet) -> {
			if(command == "executeRound"){
				if(target.getActualClass() == Agent.class){
					try {
						Agent.class.getMethod("executeRound").invoke(target);
					} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException
							| NoSuchMethodException | SecurityException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		});
	}
	
	@Override
	public void setDefaultInstanceInformationEvaluator(){
		//To be overridden
		this.setInstanceInformationEvaluator((target, command, dataSet) -> {
			return null;
		});
	}
	
	public void setDefaultRoundExecutor(){
		//To be overridden
		this.setRoundExecutor(() -> {
			turnOngoing = true;
			targetQueue = new LinkedList<Agent>();
			for(Agent agent : roundControlTargets){
				targetQueue.add(agent);
			}
			proceedToNextTarget();
		});
	}
	public void proceedToNextTarget(){
		if(turnOngoing){
			if(targetQueue.isEmpty() == true){
				turnOngoing = false;
				Chronos.proceedToNextController();
			}
			else{
			targetQueue.element().executeRound();
			targetQueue.remove();
			}
		}
	}
	public ArrayList<Agent> getRoundControlTargets() {
		return roundControlTargets;
	}
	public void setRoundControlTargets(ArrayList<Agent> roundControlTargets) {
		this.roundControlTargets = roundControlTargets;
	}
	public void addRoundControlTarget(Agent roundControlTarget){
		roundControlTargets.add(roundControlTarget);
		roundControlTarget.addParentController(this);
	}
	public Queue<Agent> getTargetQueue() {
		return targetQueue;
	}
	public void setTargetQueue(Queue<Agent> targetQueue) {
		this.targetQueue = targetQueue;
	}
	public boolean isTurnOngoing() {
		return turnOngoing;
	}
	public void setTurnOngoing(boolean turnOngoing) {
		this.turnOngoing = turnOngoing;
	}
}
