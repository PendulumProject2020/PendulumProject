package fairyChessPack1;

import main.DataSet;

@FunctionalInterface
public interface InputCommandConverter {
	public void convertInputToCommand(DataSet supportDataSet);
}
