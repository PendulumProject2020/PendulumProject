package fairyChessPack1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javafx.event.Event;
import main.DataSet;
import main.MethodPiece;
import main.Pair;
import main.SlotPath;

public class EpifyteDisplayEventInterpreter extends MethodPiece{
	private static Map<Pair<Epifyte, Event>, InputCommandConverter> interpreter;
	
	public static void addConverter(Epifyte source, Event event, InputCommandConverter inputCommandConverter){
		interpreter.put(new Pair<Epifyte, Event>(source, event), inputCommandConverter);
	}

	public static Map<Pair<Epifyte, Event>, InputCommandConverter> getInterpreter() {
		return interpreter;
	}
	
	public static void executeConverter(Epifyte source, Event event, DataSet supportDataSet){
		interpreter.get(new Pair<Epifyte, Event>(source, event)).convertInputToCommand(supportDataSet);
	}

	public static void setInterpreter(Map<Pair<Epifyte, Event>, InputCommandConverter> interpreter) {
		EpifyteDisplayEventInterpreter.interpreter = interpreter;
	}
	
	//What slots it can fit in
		public static ArrayList<SlotPath> getPossibleFits(){//Basically an override-able static final
			ArrayList<String> hostPath = new ArrayList<String>(Arrays.asList("Chronos", "Agent", "Epifyte"));
			String slotName = "EVENTINTERPRETERSLOT";
			ArrayList<SlotPath> possibleFits = new ArrayList<SlotPath>(Arrays.asList(new SlotPath(hostPath, slotName)));
			return possibleFits;
			//Use full slot names
		}
		//What method slots it has
		public static Map<String, Integer> getMethodPieceSlots(){//Basically an override-able static final
			return new HashMap<String, Integer>();//Rewrite this when you make actual pieces
			//Use simple slot names
		}
		//What object slots it has
		public static Map<String, Integer> getObjectPieceSlots(){//Basically an override-able static final
			return new HashMap<String, Integer>();//Rewrite this when you make actual pieces
			//Use simple slot names
		}
		//It needs to have these pieces in order to be activated.
		public static ArrayList<String> getDependentPieceNames(){//Basically an override-able static final
			return new ArrayList<String>();//Rewrite this when you make actual pieces
		}
		public static String getVersionName(){//Basically an override-able static final
			return "";//Rewrite this when you make actual pieces
		}
		public static void executeProcess(String processName){
			//To be rewritten
		}
		public static void executeProcessWithDataSet(String processName, DataSet dataSet){
			//To be rewritten
		}
		
		public static DataSet evaluateStaticInformation(String informationName){
			return null;
			//To be rewritten
		}
		public static DataSet evaluateStaticInformationWithDataSet(String informationName, DataSet dataSet){
			return null;
			//To be rewritten
		}
	
}
