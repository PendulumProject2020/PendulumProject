package fairyChessPack1;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;

import chronosPack.Agent;
import main.DataSet;
import main.Piece;
import main.SlotPath;
import main.Trilean;

public class EpifyteModifier extends Epifyte{
	//If the same kind of data can be modified by multiple modifiers on the same layer of binding,
	//which one actually acts on the data will simply depend on their position in the Upper ArrayList of
	//the Epifyte they bind to.
	public EpifyteModifier(){
		super();
		this.setActualClass(EpifyteModifier.class);
		this.setDefaultCommandExecuter();
		this.setDefaultInstanceInformationEvaluator();
		this.setDefaultRoundExecutor();
	}
	
	public static String getVersionName(){
		return "0.0.5 Official Pre-release";
	}
	public static ArrayList<SlotPath> getPossibleFits(){
		ArrayList<String> hostPath = new ArrayList<String>(Arrays.asList("Chronos", "Agent"));
		String slotName = "_OBJECTMEGASLOT";
		ArrayList<SlotPath> possibleFits = new ArrayList<SlotPath>(
				Arrays.asList(new SlotPath(hostPath, slotName)));
		return possibleFits;
	}
	
	public Trilean canBindTo(Epifyte epifyte){//To be overridden
		//Whether this can go on top of the given epifyte
		return Trilean.UNDECIDED;
	}
	
	public Trilean canBeBoundBy(Epifyte epifyte){//To be overridden
		//Whether the given epifyte can go on top of this
		return Trilean.UNDECIDED;
	}
	
	public static Map<String, Integer> getMethodPieceSlots(){
		return Piece.makeSimpleSlotList("BINDINGVALIDITYEVALUATORSLOT");//TODO
	}
	public static Map<String, Integer> getObjectPieceSlots(){
		return Piece.makeSimpleSlotList();//TODO
	}
	public static ArrayList<String> getDependentPieceNames(){
		return new ArrayList<String>(Arrays.asList("EpifyteModifier", "EpifyteArm"));
	}
	public static void executeProcess(String processName){
		//To be rewritten
	}
	
	public static void executeProcessWithDataSet(String processName, DataSet dataSet){
		//To be rewritten
	}
	
	@Override
	public void setDefaultCommandExecuter(){
		//To be overridden
		this.setCommandExecutor((target, command, dataSet) -> {
			if(command == "executeRound"){
				if(target.getActualClass() == Agent.class){
					try {
						Agent.class.getMethod("executeRound").invoke(target);
					} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException
							| NoSuchMethodException | SecurityException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			else{
				String[] commandArray = command.split(" ");
				if(commandArray[0] == "epifyteDo"){
					//TODO
				}
			}
		});
	}
	
	@Override
	public void setDefaultInstanceInformationEvaluator(){
		//To be overridden
		this.setInstanceInformationEvaluator((target, informationName, dataSet) -> {
			String[] informationNameArray = informationName.split(" ");
			if(informationNameArray[0] == "epifyteSeek"){
				//TODO
			}
			return null;
		});
	}
	
	@Override
	public void setDefaultRoundExecutor(){
		//To be overridden
		this.setRoundExecutor(() -> {
			//Do nothing
		});
	}
}
