package fairyChessPack1;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;

import chronosPack.Agent;
import main.*;

public class Epifyte extends Agent{
	
	private String label;
	private ArrayList<Epifyte> upper;
	private ArrayList<EpifyteModifier> upperModifiers;
	private ArrayList<EpifyteArm> upperArms;
	private ArrayList<Epifyte> lower;
	
	public Epifyte(){
		super();
		this.setActualClass(Epifyte.class);
		this.setDefaultCommandExecuter();
		this.setDefaultInstanceInformationEvaluator();
		this.setDefaultRoundExecutor();
	}
	
	public static String getVersionName(){
		return "0.0.5 Official Pre-release";
	}
	public static ArrayList<SlotPath> getPossibleFits(){
		ArrayList<String> hostPath = new ArrayList<String>(Arrays.asList("Chronos", "Agent"));
		String slotName = "_OBJECTMEGASLOT";
		ArrayList<SlotPath> possibleFits = new ArrayList<SlotPath>(
				Arrays.asList(new SlotPath(hostPath, slotName)));
		return possibleFits;
	}
	
	public Trilean canBindTo(Epifyte epifyte){//To be overridden
		//Whether this can go on top of the given epifyte
		return Trilean.UNDECIDED;
	}
	
	public Trilean canBeBoundBy(Epifyte epifyte){//To be overridden
		//Whether the given epifyte can go on top of this
		return Trilean.UNDECIDED;
	}
	
	public Trilean canDetachFrom(Epifyte epifyte){//To be overridden
		//Whether this can unbind from the given epifyte
		if(this.lower.contains(epifyte)){
			//It hasn't bound in the first place
			return Trilean.FALSE;
		}
		else{
			return Trilean.TRUE;
		}
	}
	
	public Trilean canBeDetachedBy(Epifyte epifyte){//To be overridden
		//Whether the given epifyte can unbind from this
		if(this.upper.contains(epifyte)){
			//It wasn't bound in the first place
			return Trilean.FALSE;
		}
		else{
			return Trilean.TRUE;
		}
	}
	
	public static void attemptBind(Epifyte binder, Epifyte target){//Binder would go on top of the target
		if(evaluateBindingValidity(binder, target) == true){
			forceBind(binder, target);
		}
	}
	
	public static void forceBind(Epifyte binder, Epifyte target){
		binder.getLower().add(target);
		target.getUpper().add(binder);
		if(binder.getActualClass().isAssignableFrom(EpifyteModifier.class)){
			target.getUpperModifiers().add((EpifyteModifier) binder);
			if(binder.getActualClass().isAssignableFrom(EpifyteArm.class)){
				target.getUpperArms().add((EpifyteArm) binder);
			}
		}
	}
	
	public static boolean evaluateBindingValidity(Epifyte binder, Epifyte target){//Helper method
		try {
			Method method = PieceTreeCompiler.getMethodPieceClass("BINDINGVALIDITYEVALUATORSLOT")
					.getMethod("evaluateTrilean", Trilean.class, Trilean.class);
			return (boolean) method.invoke(null, binder.canBindTo(target), target.canBeBoundBy(binder));
		} catch (NoSuchMethodException | SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public static Map<String, Integer> getMethodPieceSlots(){
		return Piece.makeSimpleSlotList("BINDINGVALIDITYEVALUATORSLOT");//TODO
	}
	public static Map<String, Integer> getObjectPieceSlots(){
		return Piece.makeSimpleSlotList();//TODO
	}
	public static ArrayList<String> getDependentPieceNames(){
		return new ArrayList<String>(Arrays.asList("EpifyteModifier", "EpifyteArm"));
	}
	public static void executeProcess(String processName){
		//To be rewritten
	}
	
	public static void executeProcessWithDataSet(String processName, DataSet dataSet){
		//To be rewritten
	}
	
	@Override
	public void setDefaultCommandExecuter(){
		//To be overridden
		this.setCommandExecutor((target, command, dataSet) -> {
			if(command == "executeRound"){
				if(target.getActualClass() == Agent.class){
					try {
						Agent.class.getMethod("executeRound").invoke(target);
					} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException
							| NoSuchMethodException | SecurityException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			else{
				String[] commandArray = command.split(" ");
				if(commandArray[0] == "epifyteDo"){
					//TODO
				}
			}
		});
	}
	
	@Override
	public void setDefaultInstanceInformationEvaluator(){
		//To be overridden
		this.setInstanceInformationEvaluator((target, informationName, dataSet) -> {
			String[] informationNameArray = informationName.split(" ");
			if(informationNameArray[0] == "epifyteSeek"){
				//TODO
			}
			return null;
		});
	}
	
	@Override
	public void setDefaultRoundExecutor(){
		//To be overridden
		this.setRoundExecutor(() -> {
			//Do nothing
		});
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public ArrayList<Epifyte> getUpper() {
		return upper;
	}

	public void setUpper(ArrayList<Epifyte> upper) {
		this.upper = upper;
	}

	public ArrayList<Epifyte> getLower() {
		return lower;
	}

	public void setLower(ArrayList<Epifyte> lower) {
		this.lower = lower;
	}

	public ArrayList<EpifyteModifier> getUpperModifiers() {
		return upperModifiers;
	}

	public void setUpperModifiers(ArrayList<EpifyteModifier> upperModifiers) {
		this.upperModifiers = upperModifiers;
	}

	public ArrayList<EpifyteArm> getUpperArms() {
		return upperArms;
	}

	public void setUpperArms(ArrayList<EpifyteArm> upperArms) {
		this.upperArms = upperArms;
	}
}
