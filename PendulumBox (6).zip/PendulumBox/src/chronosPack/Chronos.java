package chronosPack;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import main.DataSet;
import main.MethodPiece;
import main.Piece;
import main.PieceTreeCompiler;
import main.SlotPath;

public class Chronos extends MethodPiece{

	public static String getVersionName(){
		return "0.0.5 Official Pre-release";
	}
	public static ArrayList<SlotPath> getPossibleFits(){
		ArrayList<SlotPath> possibleFits = new ArrayList<SlotPath>(Arrays.asList(new SlotPath()));
		return possibleFits;
	}
	
	public static Map<String, Integer> getMethodPieceSlots(){
		return Piece.makeSimpleSlotList("INITIALIZERSLOT");//TODO
	}
	public static Map<String, Integer> getObjectPieceSlots(){
		return Piece.makeSimpleSlotList("ROUNDSIGNALLERSLOT", "AGENTSLOT");//TODO
	}
	public static ArrayList<String> getDependentPieceNames(){
		return new ArrayList<String>();//No dependency because it is a root piece
	}
	public static void run(){
		Class<Piece> initializerClass = PieceTreeCompiler.getSingleSlotOccupant(Chronos.class, "INITIALIZERSLOT");
		Method initialize;
		try {
			initialize = initializerClass.getMethod("initialize");
			initialize.invoke(null);
		} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException |
				NoSuchMethodException | SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void addRoundController(Agent roundController){
		//Not sure if this works
		Chronos.getRoundControllers().add(roundController);
	}
	public static void removeRoundController(Agent roundController){
		//Not sure if this works
		Chronos.getRoundControllers().remove(roundController);
	}
	public static ArrayList<Agent> getRoundControllers(){
		//Not sure if this works
		return (ArrayList<Agent>) PieceTreeCompiler.extractAsDataSet(Chronos.class, "roundControllers")
				.presentAsArrayList();
	}
	public static void setRoundControllers(ArrayList<Agent> roundControllers){
		PieceTreeCompiler.extractAsDataSet(Chronos.class, "roundControllers").setEntryType(ArrayList.class);
		PieceTreeCompiler.extractAsDataSet(Chronos.class, "roundControllers").setEntry(roundControllers);
	}
	public static void signalAll(){
		for(Agent roundController : Chronos.getRoundControllers()){
			roundController.executeRound();
		}
	}
	public static void executeProcess(String processName){
		//To be rewritten
	}
	public static void executeProcessWithDataSet(String processName, DataSet dataSet){
		//To be rewritten
	}
	
}
