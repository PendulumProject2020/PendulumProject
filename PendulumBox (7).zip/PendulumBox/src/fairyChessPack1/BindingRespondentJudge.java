package fairyChessPack1;

import main.Trilean;

@FunctionalInterface
public interface BindingRespondentJudge {
	public Trilean canBeBoundBy(Epifyte epifyte);
}
