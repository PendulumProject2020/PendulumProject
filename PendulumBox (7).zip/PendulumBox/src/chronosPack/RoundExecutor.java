package chronosPack;

@FunctionalInterface
public interface RoundExecutor {
	public void interfaceExecuteRound();
}
